
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register Now</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>

<body style="background-color: green;">
    <div class="container card-body mt-5">
        <img src="image/schoollogo.png" alt="school" class="mx-auto d-block rounded-circle" style="width: 10%;">
        <form action="" method="post">
            <div class="row">
                <div class="col-md-12 col-lg-6 mx-auto p-5 mb-5 pb-5" style="background-color: whitesmoke;">
                <h3 class="text-center text-success">Feedback Form</h3>
                <hr>
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" placeholder="Your Name" name="username" required>
                        <label for="floatingInput">Your Name</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" placeholder="Email" name="email" required>
                        <label for="Email">Teacher Name</label>
                    </div>
                    <div class="form-group">
                    <label for="Email">Message</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="7" required></textarea>
                    </div>
                  
                    <div class="form-group mt-3">
                    <button type="submit" class="btn btn-success form-control" name="submit">Register</button>

                    </div>

        
                </div>

            </div>

        </form>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
    </script>
</body>
</html>