<!DOCTYPE html>
<html>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
<body>
<form>
<div data-ng-app="" data-ng-init="full;advace">

<h2>Cost Calculator</h2>

Full Course fees: <input type="number" ng-model="full"> <br> <br>

Advace payment: <input type="number" ng-model="advace"> <br> <br>

<label for="">Balance</label>
<input type="text" value="{{full-advace}}">


</form>

</div>

</body>
</html>
