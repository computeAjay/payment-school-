<?php 
 include 'connect.php';
 $id=$_GET['id'];
 $sql="select * from fees where id=$id";
 $result=mysqli_query($conn,$sql);
 if(mysqli_num_rows($result) > 0 ){
   while($row=mysqli_fetch_assoc($result)){
       $name=$row['name'];
       $fees=$row['st_fees'];
       $total=$row['st_total'];
       $balance=$row['balance'];
       $date=$row['date'];

   }

}

$id=$_GET['id'];
if(isset($_POST['pay_now'])){
    $name=$_POST['name'];
    $due_balance=$_POST['due_balance'];
    $pay=$_POST['pay'];
    $date=$_POST['date'];
    $remark=$_POST['remark'];
    $g_balance= $balance-$pay;
    $totalpaid=$pay+$fees;
    $sql="INSERT INTO `fees_tran` (`id`, `name`, `due_balance`, `pay`, `date`, `remark`, `g_balance`,`Total_paid`,`courses` ) VALUES ('$id', '$name', '$due_balance', '$pay', '$date', '$remark', '$g_balance', '$totalpaid', '$total')";
    $result=mysqli_query($conn,$sql);
    if($result){
        header('location: view.php');
        // echo "New Record created Successfully";
    }else{
        echo "No Inserted in Database! ";
    }


}
$id=$_GET['id'];
if(isset($_POST['pay_now'])){
    $balance=$_POST['due_balance'];
    $pay=$_POST['pay'];
    $u_update=$balance-$pay;
    $up="update fees set balance=$u_update, st_fees=$totalpaid where id=$id";
    $result=mysqli_query($conn,$up);
    if($result){
        echo "update successfully !";
    }else{
        echo "no update database";
    }

    
}


?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
  </head>
  <body>
<div class="container" data-ng-app="" data-ng-init="advace; full">
    <div class="col-lg-6 col-md-12 mx-auto mt-3 card p-5">
    <h3>Pay now </h3>
    <hr>

        <form action="" method="post">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" name="name" placeholder="type here name" value="<?php echo $name;?>">            
            </div>
            <div class="form-group">
                <label for="name"> Due Balance</label>
                <input type="text" class="form-control" value="<?php echo $balance;?>" name="due_balance">            
            </div>
            <div class="form-group">
                <label for="name">Pay</label>
                <input type="text" class="form-control" name="pay" placeholder="type here total fees" >            
            </div>
            <div class="form-group">
                <label for="name">Date</label>
                <input type="date" class="form-control" name="date" placeholder="type here total fees" >            
            </div>
            <div class="form-group">
                <label for="name">Remark</label>
                <input type="text" class="form-control" name="remark" placeholder="type here total fees" >            
            </div>

            <div class="form-group mt-3">
               <button type="submit" class="btn btn-success" name="pay_now">Pay Now</button>          
            </div>

        
        </form>

    </div>
    
</div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js" integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous"></script>
  </body>
</html>