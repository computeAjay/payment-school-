<?php 
$server = "localhost";
$username = "root";
$password = "";
$database = "pay";
$conn= mysqli_connect($server,$username,$password,$database);
// check connection 
if(!$conn){
    die("connection failed:" . mysqli_connect_error());
}
// echo "Connected successfully";




?>