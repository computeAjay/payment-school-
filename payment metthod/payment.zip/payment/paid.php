<?php 
include 'connect.php';
if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $fees = $_POST['fees'];
    $total = $_POST['total'];
    $balance = $_POST['balance'];
    $date=$_POST['date'];
    $mark=$_POST['mark'];
    $sqli="INSERT INTO fees (name, st_fees, st_total, balance, date, Mark) VALUES ('$name', '$fees', '$total', '$balance', '$date', '$mark')";
    $result=mysqli_query($conn,$sqli);
    
        $select="select * from fees";
        // select query
        $select_r=mysqli_query($conn,$select);
        if(mysqli_num_rows($select_r) > 0 ){
            while($row=mysqli_fetch_assoc($select_r)){
             $id=$row['id'];
       
            }

    }
    $sql="insert into fees_tran (id, name, pay, date, remark, Total_paid ,courses) values ('$id', '$name', '$fees', '$date','$mark','$fees', '$total')";
    $result=mysqli_query($conn,$sql);

    if($result){
            // echo "inserted Successfully";
            header('location: view.php');
        }else{
            echo "No inserted database";
        }
}

   
 

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
  </head>
  <body>
<div class="container" data-ng-app="" data-ng-init="advace; full">
    <div class="col-lg-6 col-md-12 mx-auto mt-3 card p-5">
    <h3>Payment Processing </h3>
    <hr>

        <form action="" method="post">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" name="name" placeholder="type here name" required>            
            </div>
            <div class="form-group">
                <label for="name">Advace fees</label>
                <input type="number" class="form-control" name="fees" placeholder="Type here fees" required ng-model="advace">            
            </div>
            <div class="form-group">
                <label for="name">Fees Courses</label>
                <input type="number" class="form-control" name="total" placeholder="type here total fees" required ng-model="full">            
            </div>
            <div class="form-group">
                <label for="name"> Due Balance</label>
                <input type="text" class="form-control" value="{{full-advace}}" name="balance">            
            </div>
            <div class="form-group">
                <label for="name">Date</label>
                <input type="datetime-local" class="form-control" name="date" placeholder="type here total fees" required>            
            </div>
            <div>
                <label for="">  Remark </label>
                <input type="text" name="mark" class="form-control" placeholder="Type remark">
            
            </div>

            <div class="form-group mt-3">
               <button type="submit" class="btn btn-success" name="submit">Pay Now</button>          
            </div>
        
        </form>

    </div>
    
</div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js" integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous"></script>
  </body>
</html>

