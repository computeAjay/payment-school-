<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>michael school</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
  <style>
    aside {
    width: 40%;
    padding-left: 0.5rem;
    margin-left: 0.5rem;
    float: right;
    box-shadow: inset 5px 0 5px -5px #29627e;
    font-style: italic;
    color: #29627e;
}

aside > p {
    margin: 0.5rem;
}

p {
    font-family: 'Fira Sans', sans-serif;
}
.text{
  margin-left: 40%;
}
.list-unstyled li a{
  text-decoration: none;
}
  </style>

</head>

<body>
  <!-- heder1 start -->
  <div class="header1 bg-dark text-light">
    <div class="d-flex flex-row bd-highlight mb-1 col-lg-12 col-md-6 col-sm-6">
      <div class="p-0 bd-highlight page mt-1">
        <!-- <p>ajayparshad7012@gmail.com</p> -->

      </div>
      <div class="p-0 bd-highlight page mt-1">
        <!-- <p>St. Michael public school, Atka</p> -->

      </div>
      <div class="p-0 bd-highlight page mt-1">
        <p>Call Now <span class="text-danger">7021539478</span></p>

      </div>

    </div>

  </div>

  <!-- heder1 end -->
  <marquee behavior="alternate" direction="right" bgcolor="red">St Michael Public School</marquee>

  <div class="header">
    <div class="d-flex flex-row bd-highlight mb-3">
      <div class="p-2 bd-highlight">
        <a href="index.php"><img src="image/logo.png" alt="" width="80" height="76"></a>

      </div>
      <div class="p-4 bd-highlight">
        <h3>St. Michael public school, Atka</h3>

      </div>

    </div>

  </div>

  <nav class="navbar navbar-expand-lg bg-body-tertiary  bg-dark" data-bs-theme="dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#"><span><i class="bi bi-house-gear"></i></span></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Notice.php">Notice</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about.php">About</a>
          </li>
        </ul>
        <form class="d-flex" role="search">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
      </div>
    </div>
  </nav>
  <!-- slid menu  -->
  <div class="slide">
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="image/img1.jpg" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
          <img src="image/img2.jpg" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
          <img src="image/img2.jpg" class="d-block w-100" alt="...">
        </div>
      </div>
    </div>

  </div>
  <hr>

  <!-- section start -->
  <aside class=" col-lg-4 col d-none d-sm-block">
    <marquee behavior="" direction="up">
    <p>St Michael Public School, Atka</p>

   <p>A school is an educational institution designed to provide learning spaces and learning environments for the teaching of students under the direction of teachers. Most countries have systems of formal education, which is sometimes compulsory. In these systems, students progress through a series of schools.</p>

   <p>विद्यालय वह स्थान है, जहाँ शिक्षा ग्रहण की जाती है। "विद्यालय एक ऐसी संस्था है, जहाँ बच्चों के शारीरिक, मानसिक, बौद्धिक एवं नैतिक गुणों का विकास होता है। ' विद्यालय' शब्द के लिए आंग्ल भाषा में 'स्कूल' शब्द का प्रयोग होता है, जिसकी उत्पत्ति ग्रीक शब्द 'Skohla' या 'Skhole' से हुई है, जिससे तात्पर्य है- 'अवकाश'।</p>
    
</marquee>

</aside>
  <div class="container col-lg-8 col-md-12 sm-12 border p-5">
    <h3 style="text-decoration: underline; text-decoration-color: chocolate;" class="card-title pb-3" >Login </h3>
    <div class="section card">
      <div class="d-flex flex-row bd-highlight mb-3">
        <div class="p-2 bd-highlight">
          <a href="#" class="btn btn-success p-4"> <h2> <i class="bi bi-person-video3"></i></h2> Teacher Login </a>

        </div>
        <div class="p-2 bd-highlight">
          <a href="#" class="btn btn-success p-4"> <h2><i class="bi bi-person-bounding-box"></i></h2> Student Login</a>

        </div>

      </div>
      <div class="d-flex flex-row bd-highlight mb-4">
        <div class="p-2 bd-highlight">
          <a href="#" class="btn btn-success p-4"> <h2><i class="bi bi-people"></i></h2> Principal Login</a>

        </div>
        <div class="p-2 bd-highlight">
          <a href="feedback.php" class="btn btn-success p-4"><h2><i class="bi bi-book-fill"></i></h2> Feedback Form</a>

        </div>

      </div>


    </div>

  </div>
  <hr>
  <!-- teacher team start -->
   <!-- Image teacher -->
 <div class="container card p-5">
  <h2 style="margin-left: 44%; color: peru">Teacher Team</h2>
  <div class="row">
    <div class="col img-thumbnail bg-dark text-light">
      <img src="image/ajay.png" alt="ajay" width="236" height="236" class="img-thumbnail ms-3">
      <figcaption>
      <hr>
        <p>Name: Ajay Kumar</p>
        <p>Degree: B.Com, M.com, website Developer</p>
        <p>mob: 7021539478</p>
      </figcaption>

    </div>
    <div class="col img-thumbnail bg-dark text-light">
      <img src="image/Durga.jpg" alt="durga" width="236" height="236" class="img-thumbnail ms-3">
      <figcaption>
      <hr>
        <p>Name: Durga Ravidas</p>
        <p>Degree: B.Sc, DELED, B.BLIB</p>
        <p>mob: 8340583829</p>
      </figcaption>

    </div>
    <div class="col img-thumbnail bg-dark text-light">
      <img src="image/ramesh.png" alt="ajay" width="236" height="100" class="img-thumbnail ms-3">
      <figcaption>
      <hr>
        <p>Name: Ramesh Kumar</p>
        <p>Degree: I.A, B.A</p>
        <p>mob: 8709417323</p>
      </figcaption>

    </div>
    <div class="col img-thumbnail bg-dark text-light">
      <img src="image/Dhaneshwar.jpg" alt="boy" width="236" height="236" class="img-thumbnail ms-3">
      <figcaption>
      <hr>
        <p>Name: Dhaneshwar Nayak</p>
        <p>Degree: B.A+ DELED</p>
        <p>mob: 7488148112</p>
      </figcaption>

    </div>
    <hr>

      
    </div>
    <div class="row">
    <div class="col img-thumbnail bg-dark text-light">
      <img src="image/Jhuli.jpg" alt="Jhuli" width="236" height="236" class="img-thumbnail ms-3">
      <figcaption>
        <hr>
        <p>Name: Jhuli Madam </p>
        <p>Degree: </p>
        <p>mob: 7004917440</p>
      </figcaption>

    </div>
    <div class="col img-thumbnail bg-dark text-light">
      <img src="image/bablu.jpg" alt="ajay" width="236" height="236" class="img-thumbnail ms-3">
      <figcaption>
      <hr>
        <p>Name: Bablu Kumar Das</p>
        <p>Degree: M.A, DELED, B.LIB</p>
        <p>mob: 7488216658</p>
      </figcaption>

    </div>
    <div class="col img-thumbnail bg-dark text-light">
      <img src="image/girl.png" alt="kajal" width="236" height="236" class="img-thumbnail ms-3">
      <figcaption>
      <hr>
        <p>Name: Kajal Kumari</p>
        <p>Degree: B.Sc</p>
        <p>mob: 000000000</p>
      </figcaption>

    </div>
    <div class="col img-thumbnail bg-dark text-light">
      <img src="image/girl.png" alt="jyoti" width="236" height="236" class="img-thumbnail ms-3">
      <figcaption>
      <hr>
        <p>Name: Jyoti Kumari</p>
        <p>Degree: B.A</p>
        <p>Mob: 000000000</p>
      </figcaption>

    </div>
    <hr>
    <div class="row">
    <div class="col img-thumbnail bg-dark text-light">
      <img src="image/girl.png" alt="Jhuli" width="236" height="236" class="img-thumbnail ms-3">
      <figcaption>
        <hr>
        <p>Name: Rekha Kumari </p>
        <p>Degree: B.A</p>
        <p>mob: 0000000000</p>
      </figcaption>

    </div>
    <div class="col img-thumbnail bg-dark text-light">
      <img src="image/girl.png" alt="ajay" width="236" height="236" class="img-thumbnail ms-3">
      <figcaption>
      <hr>
        <p>Name: Puja Kumari</p>
        <p>Degree: B.A</p>
        <p>mob: 000000000</p>
      </figcaption>

    </div>
    <div class="col img-thumbnail bg-dark text-light">
      <!-- <img src="" alt="kajal" width="236" height="236" class="img-thumbnail ms-3">
      <figcaption>
      <hr>
        <p>Name: </p>
        <p>Degree: B.Sc</p>
        <p>mob: 000000000</p>
      </figcaption> -->

    </div>
    <div class="col img-thumbnail bg-dark text-light">
      <!-- <img src="image/girl.png" alt="jyoti" width="236" height="236" class="img-thumbnail ms-3">
      <figcaption>
      <hr>
        <p>Name: Jyoti Kumari</p>
        <p>Degree: B.A</p>
        <p>Mob: 000000000</p>
      </figcaption>
 -->
  </div>
 </div>
  
 </div>
</div>
<!-- teacher team end -->






  <!-- section end -->
  <hr>
  <!-- footer  start-->
  <section class="">
  <!-- Footer -->
  <footer class="bg-secondary text-white">
    <!-- Grid container -->
    <div class="container p-4">
      <!--Grid row-->
      <div class="row">
        <!--Grid column-->
        <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
          <h5 class="text-uppercase">Footer Content</h5>

          <p>
          A school is an educational institution designed to provide learning spaces and learning environments for the teaching of students under the direction of teachers.
          </p>
          <img src="image/logo.png" alt="logo" width="100" height="100">
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase">Teacher</h5>

          <ul class="list-unstyled mb-0">
            <li>
              <a href="#!" class="text-white">AJay Kumar</a>
            </li>
            <li>
              <a href="#!" class="text-white">Durga Ravidash</a>
            </li>
            <li>
              <a href="#!" class="text-white">Kundan pandey</a>
            </li>
            <li>
              <a href="#!" class="text-white">Bablu Kumar</a>
            </li>
            <li>
              <a href="#!" class="text-white">Daneshwar Kumar</a>
            </li>
            <li>
              <a href="#!" class="text-white">Jhuli Madam</a>
            </li>
            <li>
              <a href="#!" class="text-white">Kajal Madam</a>
            </li>
            <li>
              <a href="#!" class="text-white">Jyoti Madam</a>
            </li>
          </ul>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-0">School Controlar</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Dhaneshwar Nayak</a>
            </li>
            <li>
              <a href="#!" class="text-white">Jhuli Madam</a>
            </li>
            </li>
            <li>
              <a href="#!" class="text-white">Devchandra Kumar</a>
            </li>
          </ul>
        </div>
        <!--Grid column-->
      </div>
      <!--Grid row-->
    </div>
    <!-- Grid container -->

    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    © <?php echo date("Y"); ?> Copyright.
      <a class="text-white" href="#">St Michael Public School</a>
    </div>
    <!-- Copyright -->
  </footer>
  <!-- Footer -->
</section>
  <!-- footer  end-->

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous">
  </script>
</body>

</html>