<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
  </head>
  <body>
    <div class="container mt-3">
        <h3>Payment Recived Report</h3>
        <hr>
    <table class="table">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">Name</th>
      <th scope="col">paid Fees</th>
      <th scope="col">Courses</th>
      <th scope="col">Dues Fees</th>
      <th scope="col">Date</th>
      <th scope="col">Remark</th>



    </tr>
  </thead>
  <?php 
  include 'connect.php';
  $sql="select * from fees";
  $result=mysqli_query($conn,$sql);
  if(mysqli_num_rows($result) > 0 ){
    while($row=mysqli_fetch_assoc($result)){
        $id=$row['id'];
        $name=$row['name'];
        $fees=$row['st_fees'];
        $total=$row['st_total'];
        $balance=$row['balance'];
        $date=$row['date'];
        $mark=$row['Mark'];


        echo ' <tbody>
        <tr>
          <th>'.$id.' </th>
          <td>'.$name.'</td>
          <td>'.$fees.'</td>
          <td>'.$total.'</td>
          <td>'.$balance.'</td>
          <td>'.$date.'</td>
          <td>'.$mark.'</td>

          <td><a href="pay.php?id='.$id.'" class="btn btn-success">Pay</a>
          <a href="info.php?id='.$id.'" class="btn btn-primary">Print</a>
          </td>
         
        </tr>
        
      </tbody>';



      

    }
  }
  
  
  
  ?>
 
</table>

        
    </div>









    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js" integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous"></script>
  </body>
</html>